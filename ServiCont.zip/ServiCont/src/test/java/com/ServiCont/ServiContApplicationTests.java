package com.ServiCont;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiContApplicationTests {

	@Test
	void contextLoads() {
	}

}
