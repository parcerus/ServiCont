package com.ServiCont;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ServiContApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiContApplication.class, args);
	}

}
